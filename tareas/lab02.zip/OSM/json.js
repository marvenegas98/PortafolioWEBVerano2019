var nodes=[
      {
        "name": "Terminal Empresarios Unidos",
	"description": "Terminal de Buses en Esparza para ir a San Jose",
	"lat": 9.9951500,
	"lng": -84.6649872
      },
      {
        "name":"Terminal de Empresarios Unidos",
	"description":"Terminal de buses de San Ram�n a Alajuela y San Jos�",
	"lat":10.0888316,
	"lng":-84.4720297
	},
	{
		"name":"Terminal de buses del Norte",
		"lat": 10.0097430,
		"lng": -84.2130795,
        "description":"Terminal de buses donde llegan los buses de Puntarenas, Guanacaste y San Carlos para ir a San Jos�"
  },
	{
		"name": "Terminal de Buses EUPSA",
		"description": "Terminal a la cual llegan los buses desde Puntarenas",
		"lat": 9.9285815,
		"lng": -84.0858709
	},
	{
	"name":"Lumaca",
	"description":"Terminal de buses de San Jos� a Cartago",
        "lat": 9.9296722,
        "lng": -84.0768181
	},
	{
	"name":"Lumaca Cartago",
	"description": "Terminal de buses de Cartago a San Jos�",
	"lat": 9.8672835,
    "lng": -83.9221378
	}
]
var markers = [
	{
	  "name":"Esparza Centro",
	  "lat":9.9909976,
	  "lng": -84.6663645
	},
	{
		"name":"La Riviera",
		"lat": 9.9964996, 
		"lng":-84.6649756
	},
	{
		"name": "Servicentro Esparza",
		"lat": 9.99479,
		"lng":-84.66583
	},
	{
		"name": "Soda la China",
		"lat": 9.99123,
		"lng":-84.66561
	},
	{
		"name": "Bomba UNO",
		"lat": 9.99669, 
		"lng": -84.67328
	},
  ];