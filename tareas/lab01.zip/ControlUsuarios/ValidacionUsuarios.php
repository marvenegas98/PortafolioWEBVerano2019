<!DOCTYPE html>
<head>
    <title>Login</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script src='animate.js'></script>
    <style>
        li {listt-style: none;}
    </style>
</head>
<body>


</body>
</html>

<?php
require('datos_base.php');
$conn = OpenCon();
if(isset($_POST['Ingresar'])) {
    $usu = mysqli_real_escape_string($conn,$_POST['user']);
    $contra = mysqli_real_escape_string($conn,$_POST['pass']); 
    $contra = md5($contra);
    $sql = "SELECT * from usuarios WHERE usuario = '$usu' AND pass = '$contra'";
    $result = mysqli_query($conn,$sql);
    $cont = mysqli_num_rows($result);
    if ($cont >= 1){
        header("Location:inicio.html");
    }
    else{        
        echo "<script type='text/javascript'>alert('Credenciales incorrectos. Favor intente de nuevo.');window.location='login.html'</script>";
    }
}

CloseCon($conn);
?>