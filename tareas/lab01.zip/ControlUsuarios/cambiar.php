<!DOCTYPE html>
<head>
    <title>Cambio de Contraseña</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script src='main.js'></script>
    <style>
        li {listt-style: none;}
    </style>
</head>
<body>


</body>
</html>

<?php
require('datos_base.php');
$conn = OpenCon();
if(isset($_POST['Cambiar'])) {
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $vieja = mysqli_real_escape_string($conn,$_POST['actual']); 
    $contra = mysqli_real_escape_string($conn,$_POST['contra']); 
    $nueva = mysqli_real_escape_string($conn,$_POST['nueva']); 
    $vieja = md5($vieja);
    $sql = "SELECT * from usuarios WHERE email = '$email' AND pass = '$vieja'";
    $result = mysqli_query($conn,$sql);
    $cont = mysqli_num_rows($result);
    if($contra!=$nueva){
        echo "<script type='text/javascript'>alert('Las contraseñas nuevas no coindicen.'); window.location = 'cambiar.html'</script>";
    }
    if($cont<1){
        echo "<script type='text/javascript'>alert('No se ha encontrado una cuenta con los credenciales dados.');window.location = 'cambiar.html'</script>";
    }
    else{
        $contra = md5($contra);
        $qry = "UPDATE usuarios SET pass = '$contra' WHERE email = '$email'";
        $result = mysqli_query($conn,$qry);
        if($result == 1){
            echo "<script type='text/javascript'>alert('Se ha modificado la contrasenna exitosamente.');window.location='login.html'</script>";
        }
        else{
            echo "<script type='text/javascript'>alert('No se pudo modificar la contrasenna. Favor intente de nuevo.');window.location='cambiar.html'</script>";
        }
    }
}
CloseCon($conn);
?>