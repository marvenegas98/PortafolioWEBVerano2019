<!DOCTYPE html>
<head>
    <title>Registro de Usuario</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script src='main.js'></script>
    <style>
        li {listt-style: none;}
    </style>
</head>
<body>


</body>
</html>

<?php
require('datos_base.php');
$conn = OpenCon();
if(isset($_POST['Registrarme'])) {
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $primer = mysqli_real_escape_string($conn,$_POST['primer']); 
    $seg = mysqli_real_escape_string($conn,$_POST['seg']); 
    $name = mysqli_real_escape_string($conn,$_POST['name']); 
    $usu = mysqli_real_escape_string($conn,$_POST['user']);
    $contra = mysqli_real_escape_string($conn,$_POST['pass']); 
    $tel = $_POST['telefono'];
    $fecha = $_POST['date']; 
    $fecha = date("Y-m-d", strtotime($date));
    $contra = md5($contra);
    $sql = "INSERT INTO usuarios(nombre, primer_apellido, seg_apellido, usuario, pass, email, celular, fecha_nacimiento) VALUES('$name','$primer','$seg','$usu','$contra','$email','$tel','$fecha')";
    $result = mysqli_query($conn,$sql);
    if($result){
        echo "<script type='text/javascript'>alert('Se ha registrado exitosamente.');window.location='login.html'</script>";
    }
    else{
        echo "<script type='text/javascript'>alert('Existe un error entre sus datos. Favor intente de nuevo.');window.location='registro.html'</script>";
    }
}
CloseCon($conn);
?>