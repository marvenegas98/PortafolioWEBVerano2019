function alert(message){
    alert(message);
}