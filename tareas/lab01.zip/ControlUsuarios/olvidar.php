<!DOCTYPE html>
<head>
    <title>Olvido de Contraseña</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script src='main.js'></script>
    <style>
        li {listt-style: none;}
    </style>
</head>
<body>


</body>
</html>
<?php
require('datos_base.php');
$conn = OpenCon();
if(isset($_POST['Enviar'])) {
    $to = mysqli_real_escape_string($conn,$_POST['email']);
    $subject = 'Reestablecer Contraseña';
    $message = 'Hola, ¿Olvidaste tu contraseña?'; 
    $from = 'someemail@email.com';
    if(mail($to, $subject, $message)){
        echo "<script type='text/javascript'>alert('Tu solicitud ha sido enviada exitosamente.');window.location='login.html'</script>";
    } else{
        echo "<script type='text/javascript'>alert('No fue posible enviar su solicitud. Favor intente de nuevo.);window.location='olvidar.html'</script>";
    }
}
CloseCon($conn);
?>